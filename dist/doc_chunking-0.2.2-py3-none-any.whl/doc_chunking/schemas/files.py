from typing import Union
from pathlib import Path

FileInputData = Union[str, bytes, Path]


