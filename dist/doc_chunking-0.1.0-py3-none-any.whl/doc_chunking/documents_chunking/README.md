# Documents Chunking

Inputs .pdf/.docx Files, steamingly/Server-Sent-Event(SSE) output a Sector Tree / layout elemnts result.


Prerequists:



